import javax.swing.*;
import java.awt.*;

public class VentanaEstudiante extends JFrame {
    private JTextField txtNombre, txtEdad, txtNotas;
    private JTextArea areaResultados;
    private Estudiante[] estudiantes;
    private int contador = 0;

    public VentanaEstudiante() {
        estudiantes = new Estudiante[3];

        setTitle("Registro de Estudiantes");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        add(new JLabel("Nombre:"));
        txtNombre = new JTextField(10);
        add(txtNombre);

        add(new JLabel("Edad:"));
        txtEdad = new JTextField(5);
        add(txtEdad);

        add(new JLabel("Notas (5 separadas por ,):"));
        txtNotas = new JTextField(15);
        add(txtNotas);

        JButton btnAgregar = new JButton("Agregar");
        add(btnAgregar);
        btnAgregar.addActionListener(e -> agregarEstudiante());

        JButton btnMostrar = new JButton("Mostrar Promedios");
        add(btnMostrar);
        btnMostrar.addActionListener(e -> mostrarPromedios());

        areaResultados = new JTextArea(8, 30);
        areaResultados.setEditable(false);
        add(new JScrollPane(areaResultados));
    }

    private void agregarEstudiante() {
        if (contador < 3) {
            try {
                String nombre = txtNombre.getText().trim();
                int edad = Integer.parseInt(txtEdad.getText().trim());
                String[] notasTexto = txtNotas.getText().trim().split(",");
                if (notasTexto.length != 5) throw new NumberFormatException();

                double[] notas = new double[5];
                for (int i = 0; i < 5; i++) {
                    notas[i] = Double.parseDouble(notasTexto[i]);
                }

                estudiantes[contador] = new Estudiante(nombre, edad, notas);
                contador++;
                txtNombre.setText("");
                txtEdad.setText("");
                txtNotas.setText("");

                if (contador == 3) {
                    JOptionPane.showMessageDialog(this, "Lista completa, muestra los resultados.", "Informacion", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingrese datos correctos porfavor", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Ya se han agregado los 3 estudiantes.", "Limite alcanzado", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void mostrarPromedios() {
        areaResultados.setText("Promedios de estudiantes:\n");
        for (int i = 0; i < contador; i++) {
            areaResultados.append(estudiantes[i].getNombre() + " - Promedio: " + String.format("%.2f", estudiantes[i].calcularPromedio()) + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaEstudiante().setVisible(true));
    }
}
