import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class ListaNombres extends JFrame {
    private ArrayList<String> nombres;
    private JTextField txtNombre, txtBuscar;
    private JTextArea areaLista;

    public ListaNombres() {
        nombres = new ArrayList<>();

        setTitle("Gestor de Nombres");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        add(new JLabel("Nombre:"));
        txtNombre = new JTextField(10);
        add(txtNombre);

        JButton btnAgregar = new JButton("Agregar");
        add(btnAgregar);
        btnAgregar.addActionListener(e -> agregarNombre());

        JButton btnEliminar = new JButton("Eliminar");
        add(btnEliminar);
        btnEliminar.addActionListener(e -> eliminarNombre());

        add(new JLabel("Buscar:"));
        txtBuscar = new JTextField(10);
        add(txtBuscar);

        JButton btnBuscar = new JButton("Buscar");
        add(btnBuscar);
        btnBuscar.addActionListener(e -> buscarNombre());

        JButton btnMostrar = new JButton("Mostrar Todos");
        add(btnMostrar);
        btnMostrar.addActionListener(e -> mostrarNombres());

        areaLista = new JTextArea(8, 30);
        areaLista.setEditable(false);
        add(new JScrollPane(areaLista));
    }

    private void agregarNombre() {
        String nombre = txtNombre.getText().trim();
        if (!nombre.isEmpty()) {
            nombres.add(nombre);
            txtNombre.setText("");
            mostrarNombres();
        }
    }

    private void eliminarNombre() {
        String nombre = txtNombre.getText().trim();
        if (nombres.remove(nombre)) {
            txtNombre.setText("");
            mostrarNombres();
        } else {
            JOptionPane.showMessageDialog(this, "Nombre no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buscarNombre() {
        String nombre = txtBuscar.getText().trim();
        if (nombres.contains(nombre)) {
            JOptionPane.showMessageDialog(this, "El nombre existe en la lista.", "Encontrado", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "El nombre NO está en la lista.", "No Encontrado", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void mostrarNombres() {
        areaLista.setText("Lista de nombres:\n");
        for (String nombre : nombres) {
            areaLista.append(nombre + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ListaNombres().setVisible(true));
    }
}
