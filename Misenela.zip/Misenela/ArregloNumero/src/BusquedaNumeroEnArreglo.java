import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class BusquedaNumeroEnArreglo extends JFrame {
    private JTextField[] camposNumeros;
    private JTextField campoBusqueda;
    private JTextArea areaResultados;
    private int[] numeros;

    public BusquedaNumeroEnArreglo() {
        setTitle("Busqueda de Numero en Arreglo");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        camposNumeros = new JTextField[10];
        for (int i = 0; i < 10; i++) {
            add(new JLabel("Número " + (i + 1) + ":"));
            camposNumeros[i] = new JTextField(5);
            add(camposNumeros[i]);
        }

        JButton btnGuardar = new JButton("Guardar Numeros");
        add(btnGuardar);
        btnGuardar.addActionListener(this::guardarNumeros);

        add(new JLabel("Numero a buscar:"));
        campoBusqueda = new JTextField(5);
        add(campoBusqueda);

        JButton btnBuscar = new JButton("Buscar");
        add(btnBuscar);
        btnBuscar.addActionListener(this::buscarNumero);

        areaResultados = new JTextArea(10, 30);
        areaResultados.setEditable(false);
        add(new JScrollPane(areaResultados));
    }

    private void guardarNumeros(ActionEvent e) {
        numeros = new int[10];
        try {
            for (int i = 0; i < 10; i++) {
                numeros[i] = Integer.parseInt(camposNumeros[i].getText().trim());
            }
            areaResultados.setText("Numeros guardados correctamente.\n");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese solo numeros enteros.", "Error de formato", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buscarNumero(ActionEvent e) {
        if (numeros == null) {
            JOptionPane.showMessageDialog(this, "Primero debe guardar los numeros.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int numeroBuscado = Integer.parseInt(campoBusqueda.getText().trim());
            StringBuilder resultado = new StringBuilder();
            boolean encontrado = false;

            for (int i = 0; i < numeros.length; i++) {
                if (numeros[i] == numeroBuscado) {
                    resultado.append("Numero encontrado en la posicion: ").append(i).append("\n");
                    encontrado = true;
                }
            }

            if (!encontrado) {
                resultado.append("Numero no encontrado en el arreglo.\n");
            }

            areaResultados.setText(resultado.toString());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese un numero entero valido para buscar.", "Error de formato", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BusquedaNumeroEnArreglo().setVisible(true));
    }
}
