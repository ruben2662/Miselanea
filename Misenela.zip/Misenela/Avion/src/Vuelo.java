import java.util.ArrayList;

public class Vuelo {
    private int numeroVuelo;
    private String origen;
    private String destino;
    private double costoPasaje;
    private ArrayList<String> pasajeros;

    public Vuelo(int numeroVuelo, String origen, String destino, double costoPasaje) {
        this.numeroVuelo = numeroVuelo;
        this.origen = origen;
        this.destino = destino;
        this.costoPasaje = costoPasaje;
        this.pasajeros = new ArrayList<>();
    }

    public int getNumeroVuelo() {
        return numeroVuelo;
    }

    public String getDestino() {
        return destino;
    }

    public double getCostoPasaje() {
        return costoPasaje;
    }

    public ArrayList<String> getPasajeros() {
        return pasajeros;
    }

    public void agregarPasajero(String nombre) {
        pasajeros.add(nombre);
    }

    public boolean buscarPasajero(String nombre) {
        return pasajeros.contains(nombre);
    }
}
