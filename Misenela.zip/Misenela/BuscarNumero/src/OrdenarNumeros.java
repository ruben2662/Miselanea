import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Collections;

public class OrdenarNumeros extends JFrame {
    private JTextField txtNumero;
    private JTextArea areaResultado;
    private ArrayList<Integer> numeros;

    public OrdenarNumeros() {
        numeros = new ArrayList<>();

        setTitle("Ordenar Numeros");
        setSize(350, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        add(new JLabel("Ingrese un numero:"));
        txtNumero = new JTextField(10);
        add(txtNumero);

        JButton btnAgregar = new JButton("Agregar");
        add(btnAgregar);
        btnAgregar.addActionListener(this::agregarNumero);

        JButton btnOrdenar = new JButton("Ordenar");
        add(btnOrdenar);
        btnOrdenar.addActionListener(this::ordenarLista);

        areaResultado = new JTextArea(10, 25);
        areaResultado.setEditable(false);
        add(new JScrollPane(areaResultado));
    }

    private void agregarNumero(ActionEvent e) {
        try {
            int num = Integer.parseInt(txtNumero.getText().trim());
            numeros.add(num);
            txtNumero.setText("");
            actualizarLista();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingrese un numero que corresponda.", "Error 404", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void ordenarLista(ActionEvent e) {
        if (numeros.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay numeros para ordenar.", "Ojo Verifiquese bien", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Collections.sort(numeros);
        actualizarLista();
    }

    private void actualizarLista() {
        areaResultado.setText("Lista de los numeros:\n" + numeros.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new OrdenarNumeros().setVisible(true));
    }
}
