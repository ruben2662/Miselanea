import javax.swing.*;
import java.awt.*;

public class VentanaCirculo extends JFrame {
    private Circulo circulo;
    private JLabel labelArea, labelCircunferencia, labelMensaje;
    private JTextField textFieldRadio;
    private JButton btnActualizar;

    public VentanaCirculo() {
        // Inicializamos in  círculo con un radio por defecto en la interfaz
        circulo = new Circulo(50); // Radio inicial 50 píxeles

        // Extensiones del perimetro de la ventana
        setTitle("Circulo: Area y Circunferencia");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel para dibujar el esquema del
        JPanel panelDibujo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Dibujar el círculo con el radio especificado
                g.setColor(Color.BLUE);
                g.fillOval(150, 50, (int)(circulo.getRadio() * 2), (int)(circulo.getRadio() * 2)); // Círculo
            }
        };

        // Crear las etiquetas para mostrar el area y circunferencia
        labelArea = new JLabel("Area: " + String.format("%.2f", circulo.calcularArea()) + " unidades cuadradas");
        labelCircunferencia = new JLabel("Circunferencia: " + String.format("%.2f", circulo.calcularCircunferencia()) + " unidades");
        labelMensaje = new JLabel("Ingrese el radio del circulo:");

        // Creacion de un campo de texto para que el usuario ingrese el radio
        textFieldRadio = new JTextField(10);
        textFieldRadio.setText(String.valueOf(circulo.getRadio())); // Mostrar el radio actual

        // Crearcion el boton para actualizar el circulo
        btnActualizar = new JButton("Actualizar Circulo");
        btnActualizar.addActionListener(e -> actualizarCirculo());

        // Añadir los componentes a la ventana
        JPanel panelTexto = new JPanel();
        panelTexto.setLayout(new BoxLayout(panelTexto, BoxLayout.Y_AXIS));
        panelTexto.add(labelMensaje);
        panelTexto.add(textFieldRadio);
        panelTexto.add(btnActualizar);
        panelTexto.add(labelArea);
        panelTexto.add(labelCircunferencia);

        add(panelDibujo, BorderLayout.CENTER);
        add(panelTexto, BorderLayout.SOUTH);

        // Hacer visible la ventana
        setVisible(true);
    }

    private void actualizarCirculo() {
        try {
            double nuevoRadio = Double.parseDouble(textFieldRadio.getText());
            if (nuevoRadio <= 0) {
                JOptionPane.showMessageDialog(this, "El radio debe ser un numero positivo", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                circulo.setRadio(nuevoRadio);
                labelArea.setText("Área: " + String.format("%.2f", circulo.calcularArea()) + " unidades cuadradas");
                labelCircunferencia.setText("Circunferencia: " + String.format("%.2f", circulo.calcularCircunferencia()) + " unidades");
                repaint();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese un numero que sea valido para el radio", "Error 404", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        // Ejecutar la aplicacion
        SwingUtilities.invokeLater(() -> new VentanaCirculo());
    }
}

