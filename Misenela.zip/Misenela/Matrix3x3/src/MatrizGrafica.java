import javax.swing.*;
import java.awt.*;

public class MatrizGrafica {
    public static void main(String[] args) {

        JFrame frame = new JFrame("Matriz 3x3 y Suma de Diagonal");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        frame.setLayout(new GridLayout(4, 1));

        JPanel matrizPanel = new JPanel();
        matrizPanel.setLayout(new GridLayout(3, 3));


        int[][] matriz = new int[3][3];
        int sumaDiagonal = 0;

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                matriz[i][j] = (int) (Math.random() * 100) + 1;
                if (i == j) {
                    sumaDiagonal += matriz[i][j];
                }
            }
        }


        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {

                JLabel label = new JLabel(String.valueOf(matriz[i][j]), SwingConstants.CENTER);
                label.setBorder(BorderFactory.createLineBorder(Color.BLACK));
                matrizPanel.add(label);
            }
        }

        
        JLabel sumaLabel = new JLabel("Suma de la diagonal principal: " + sumaDiagonal, SwingConstants.CENTER);
        frame.add(matrizPanel);
        frame.add(sumaLabel);

        // Hacer visible la ventana
        frame.setVisible(true);
    }
}
