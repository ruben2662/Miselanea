public class Producto {
    private String nombre;
    private double precio;
    private int cantidad;

    // Constructor
    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    // Métodos getter
    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    // Método para calcular el valor total de un producto (precio * cantidad)
    public double calcularValor() {
        return precio * cantidad;
    }

    // Sobreescribir el método toString() para representar el producto como una cadena
    @Override
    public String toString() {
        return nombre + " - Precio: " + precio + " - Cantidad: " + cantidad;
    }
}

