import javax.swing.*;
import java.util.ArrayList;

public class InventarioProducto {
    public static void main(String[] args) {
        // Crear un ArrayList de productos
        ArrayList<Producto> productos = new ArrayList<>();
        String menu = "1. Agregar Producto\n2. Mostrar Productos\n3. Calcular Valor Total\n4. Salir";
        int opcion;

        do {
            // Mostrar el menú
            opcion = Integer.parseInt(JOptionPane.showInputDialog(menu));

            switch (opcion) {
                case 1:
                    // Agregar un nuevo producto
                    String nombre = JOptionPane.showInputDialog("Ingrese el nombre del producto:");
                    double precio = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio del producto:"));
                    int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad del producto:"));

                    // Crear el producto y agregarlo al ArrayList
                    Producto nuevoProducto = new Producto(nombre, precio, cantidad);
                    productos.add(nuevoProducto);
                    JOptionPane.showMessageDialog(null, "Producto agregado exitosamente.");
                    break;

                case 2:
                    // Mostrar la lista de productos
                    if (productos.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No hay productos en el inventario.");
                    } else {
                        StringBuilder lista = new StringBuilder("Lista de Productos:\n");
                        for (Producto producto : productos) {
                            lista.append(producto.toString()).append("\n");
                        }
                        JOptionPane.showMessageDialog(null, lista.toString());
                    }
                    break;

                case 3:
                    // Calcular el valor total del inventario
                    double valorTotal = 0;
                    for (Producto producto : productos) {
                        valorTotal += producto.calcularValor();
                    }
                    JOptionPane.showMessageDialog(null, "El valor total del inventario es: " + valorTotal);
                    break;

                case 4:
                    // Salir
                    JOptionPane.showMessageDialog(null, "¡Hasta luego!");
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Opcion no valida, por favor intente de nuevo.");
            }
        } while (opcion != 4);
    }
}
